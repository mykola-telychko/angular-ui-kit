import { Routes } from '@angular/router';
import { DetailsComponent } from './details/details.component';
//import { HomeComponent } from './home/home.component';

// {
//     path: '',
//     component: HomeComponent,
//     title: 'Home page'
//   },
// {
//     path: 'details/:id',
//     component: DetailsComponent,
//     title: 'Home details'
//   }

// {
//     path: 'details',
//     component: DetailsComponent,
//     title: 'Home details'
// }
const routeConfig: Routes = [
  {
    path: '',
    component: DetailsComponent,
    title: 'Home details'
  }
];

export default routeConfig;

// export const routes: Routes = [];
